import { useEffect, useState, type ReactNode } from "react";
import {
  armorParts,
  curiosities,
  figures,
  glossary,
  legends,
  myths,
  periods,
  sources,
  weapons,
  type Item,
} from "./data/samurai";
import Petals from "./components/Petals";

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const p = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.7,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };
  switch (name) {
    case "arrow": return <svg {...p}><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
    case "up": return <svg {...p}><path d="M12 19V5M6 11l6-6 6 6" /></svg>;
    case "sun": return <svg {...p}><circle cx="12" cy="12" r="4.2" /><path d="M12 2v2.2M12 19.8V22M4.2 4.2l1.6 1.6M18.2 18.2l1.6 1.6M2 12h2.2M19.8 12H22M4.2 19.8l1.6-1.6M18.2 5.8l1.6-1.6" /></svg>;
    case "moon": return <svg {...p}><path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5Z" /></svg>;
    case "external": return <svg {...p}><path d="M14 4h6v6M20 4l-9 9" /><path d="M18 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h6" /></svg>;
    default: return <svg {...p}><circle cx="12" cy="12" r="8" /></svg>;
  }
}

function Reveal({ children, className = "", delay = 0 }: { children: ReactNode; className?: string; delay?: number }) {
  const [shown, setShown] = useState(false);
  const [element, setElement] = useState<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!element) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShown(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" },
    );
    observer.observe(element);
    return () => observer.disconnect();
  }, [element]);
  return (
    <div ref={setElement} className={`reveal ${shown ? "is-visible" : ""} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

function ItemCard({ item, index }: { item: Item; index: number }) {
  const [open, setOpen] = useState(false);
  return (
    <Reveal delay={(index % 3) * 70}>
      <article className={`item-card ${open ? "is-open" : ""}`}>
        {item.image && (
          <div className="item-media">
            <img src={item.image} alt={item.imageAlt ?? item.name} loading="lazy" />
          </div>
        )}
        <div className="item-body">
          <div className="item-top">
            <span className="item-jp">{item.jp}</span>
            <span className="item-era">{item.era}</span>
          </div>
          <h3>{item.name}</h3>
          <p className="item-reading">{item.reading}</p>
          <p className="item-kicker">{item.kicker}</p>
          <p className="item-text">{item.text}</p>
          <button type="button" className="item-toggle" aria-expanded={open} onClick={() => setOpen((value) => !value)}>
            {open ? "Mostrar menos" : "Ver detalhes"}
            <i>{open ? "−" : "+"}</i>
          </button>
          {open && (
            <div className="item-extra">
              <dl className="item-specs">
                {item.specs.map((spec) => (
                  <div key={spec.label}>
                    <dt>{spec.label}</dt>
                    <dd>{spec.value}</dd>
                  </div>
                ))}
              </dl>
              <p className="item-note">{item.note}</p>
            </div>
          )}
        </div>
      </article>
    </Reveal>
  );
}

export default function App() {
  const [activePeriod, setActivePeriod] = useState(periods[2].id);
  const [gallery, setGallery] = useState<"armas" | "armaduras">("armas");
  const [activeFigure, setActiveFigure] = useState(figures[0].id);
  const [openLegend, setOpenLegend] = useState<string | null>(legends[0].id);
  const [openMyth, setOpenMyth] = useState<number | null>(0);
  const [openCuriosity, setOpenCuriosity] = useState<number | null>(0);
  const [query, setQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dark, setDark] = useState(() => {
    try {
      const saved = localStorage.getItem("samurai-theme");
      if (saved) return saved === "dark";
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 28);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", dark ? "#15130f" : "#f4efe4");
    try {
      localStorage.setItem("samurai-theme", dark ? "dark" : "light");
    } catch {
      /* armazenamento opcional */
    }
  }, [dark]);

  useEffect(() => {
    const links = document.querySelectorAll<HTMLAnchorElement>(".site-nav a");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            links.forEach((link) => link.classList.toggle("active", link.hash === `#${entry.target.id}`));
          }
        });
      },
      { rootMargin: "-30% 0px -60% 0px" },
    );
    document.querySelectorAll("main section[id]").forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const period = periods.find((item) => item.id === activePeriod)!;
  const figure = figures.find((item) => item.id === activeFigure)!;
  const items = gallery === "armas" ? weapons : armorParts;
  const term = query.trim().toLowerCase();
  const filteredGlossary = glossary.filter((item) => `${item.jp} ${item.term} ${item.meaning}`.toLowerCase().includes(term));

  const close = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className={`site-header ${scrolled ? "is-scrolled" : ""}`}>
        <div className="header-inner">
          <a href="#inicio" className="brand" onClick={close} aria-label="Samurai, voltar ao início">
            <span className="brand-mon"><i /><b>侍</b></span>
            <span className="brand-name"><b>SAMURAI</b><small>HISTÓRIA · CONTEXTO · MEMÓRIA</small></span>
          </a>
          <nav className={`site-nav ${menuOpen ? "is-open" : ""}`} aria-label="Navegação principal">
            <a href="#historia" onClick={close}>História</a>
            <a href="#arsenal" onClick={close}>Armas e armaduras</a>
            <a href="#figuras" onClick={close}>Figuras</a>
            <a href="#lendas" onClick={close}>Lendas</a>
            <a href="#curiosidades" onClick={close}>Curiosidades</a>
          </nav>
          <div className="header-actions">
            <button
              className="theme-switch"
              type="button"
              onClick={() => setDark((value) => !value)}
              aria-pressed={dark}
              aria-label={dark ? "Mudar para o tema claro" : "Mudar para o tema escuro"}
            >
              <span className="theme-track" aria-hidden="true">
                <span className="theme-icon sun"><Icon name="sun" size={14} /></span>
                <span className="theme-icon moon"><Icon name="moon" size={14} /></span>
                <span className="theme-knob" />
              </span>
              <span className="theme-label">{dark ? "Escuro" : "Claro"}</span>
            </button>
            <button
              className={`menu-toggle ${menuOpen ? "open" : ""}`}
              type="button"
              onClick={() => setMenuOpen((value) => !value)}
              aria-label="Abrir menu"
              aria-expanded={menuOpen}
            >
              <span /><span />
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* ---------------- Abertura ---------------- */}
        <section className="hero" id="inicio">
          <div className="hero-image" aria-hidden="true" />
          <div className="hero-wash" aria-hidden="true" />
          <Petals className="hero-petals" density={28} />
          <div className="hero-inner">
            <Reveal className="hero-copy">
              <p className="hero-kicker"><span /> UM ARQUIVO VISUAL DA HISTÓRIA JAPONESA</p>
              <h1>Samurai:<br /><em>entre a história</em><br />e a lenda.</h1>
              <p className="hero-lead">
                Guerreiros, servidores, administradores e símbolos de uma sociedade em constante transformação.
                Mil anos de história para além da espada.
              </p>
              <div className="hero-actions">
                <a className="button button-paper" href="#historia">Percorrer a história <Icon name="arrow" size={17} /></a>
                <a className="hero-text-link" href="#lendas">Ler as lendas <span>↓</span></a>
              </div>
            </Reveal>
          </div>
          <div className="hero-footer">
            <span>日本の武士 · OS GUERREIROS DO JAPÃO</span>
            <span>HEIAN — MEIJI · SÉCULOS X–XIX</span>
          </div>
          <span className="hero-vertical" aria-hidden="true">武 · 士 · 道</span>
        </section>

        {/* ---------------- Introdução ---------------- */}
        <section className="intro-section" id="contexto">
          <div className="intro-index">01 <i /></div>
          <Reveal className="intro-copy">
            <p className="section-label"><span>UM NOME, MUITOS PAPÉIS</span></p>
            <h2>Uma história que<br />não cabe <em>numa espada.</em></h2>
            <p className="intro-lead">
              “Samurai” vem do verbo japonês <i>saburau</i>: servir, acompanhar. Ao longo de quase um milênio,
              a palavra descreveu pessoas e funções que mudaram junto com o próprio Japão.
            </p>
            <p>
              Os primeiros grupos guerreiros ganharam influência nas províncias. Depois, a classe samurai esteve
              no centro dos governos militares. Em séculos de paz, muitos passaram a trabalhar como administradores,
              estudiosos e funcionários do Estado — e alguns nunca viram uma batalha.
            </p>
            <a href="#historia" className="ink-link">Ver a linha do tempo <Icon name="arrow" size={16} /></a>
          </Reveal>
          <Reveal className="intro-aside" delay={120}>
            <span className="kanji-seal">侍</span>
            <p>Não uma personagem única.<br />Uma classe em transformação.</p>
            <small>Leitura histórica · sem romantização</small>
          </Reveal>
        </section>

        {/* ---------------- Linha do tempo ---------------- */}
        <section className="timeline-section" id="historia">
          <div className="section-topline"><span>02 / UMA CLASSE EM TRANSFORMAÇÃO</span><span>794 — 1877</span></div>
          <div className="timeline-heading">
            <Reveal>
              <p className="section-label"><span>LINHA DO TEMPO</span></p>
              <h2>Do serviço local<br />ao fim dos privilégios.</h2>
            </Reveal>
            <p>Escolha um período e veja como o papel dos samurais mudou junto com a sociedade japonesa.</p>
          </div>
          <div className="timeline-layout">
            <div className="era-list" role="tablist" aria-label="Períodos históricos">
              {periods.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={activePeriod === item.id}
                  className={`era-tab ${activePeriod === item.id ? "active" : ""}`}
                  onClick={() => setActivePeriod(item.id)}
                >
                  <span className="era-no">0{index + 1}</span>
                  <span className="era-name">{item.name}<small>{item.date}</small></span>
                  <span className="era-dot" />
                </button>
              ))}
            </div>
            <article className="era-detail" key={period.id}>
              <div className="era-detail-head">
                <span className="era-date">{period.date}</span>
                <span className="era-marker">{period.marker}</span>
              </div>
              <h3>{period.epithet}</h3>
              <p className="era-overview">{period.overview}</p>
              <div className="era-facts">
                {period.details.map((detail) => (
                  <div key={detail.label}>
                    <b>{detail.label}</b>
                    <p>{detail.text}</p>
                  </div>
                ))}
              </div>
            </article>
          </div>
        </section>

        {/* ---------------- Arsenal ---------------- */}
        <section className="arsenal-section" id="arsenal">
          <div className="section-topline"><span>03 / EQUIPAMENTO E PRÁTICA</span><span>道具 · ARMAS E ARMADURAS</span></div>
          <div className="arsenal-heading">
            <Reveal>
              <p className="section-label"><span>O ARSENAL</span></p>
              <h2>Cada arma conta<br />como se lutava.</h2>
            </Reveal>
            <p>
              O equipamento mudou conforme a guerra mudava: do arqueiro a cavalo às formações de lanceiros,
              dos arcabuzes às armaduras à prova de bala.
            </p>
          </div>
          <div className="gallery-switch" role="tablist" aria-label="Escolher categoria">
            <button type="button" role="tab" aria-selected={gallery === "armas"} className={gallery === "armas" ? "active" : ""} onClick={() => setGallery("armas")}>
              Armas <em>{weapons.length}</em>
            </button>
            <button type="button" role="tab" aria-selected={gallery === "armaduras"} className={gallery === "armaduras" ? "active" : ""} onClick={() => setGallery("armaduras")}>
              Armaduras <em>{armorParts.length}</em>
            </button>
          </div>
          <div className="item-grid" key={gallery}>
            {items.map((item, index) => <ItemCard key={item.id} item={item} index={index} />)}
          </div>
        </section>

        {/* ---------------- Citação ---------------- */}
        <section className="quote-section">
          <div className="quote-mark" aria-hidden="true">“</div>
          <Reveal>
            <p>O samurai histórico manejava armas.<br /><em>Também manejava instituições, terras e palavras.</em></p>
            <span>DA GUERRA À VIDA COTIDIANA</span>
          </Reveal>
          <div className="quote-kanji" aria-hidden="true">武<br />文</div>
        </section>

        {/* ---------------- Figuras ---------------- */}
        <section className="figures-section" id="figuras">
          <div className="section-topline"><span>04 / QUEM FOI QUEM</span><span>人物 · FIGURAS HISTÓRICAS</span></div>
          <div className="figures-heading">
            <Reveal>
              <p className="section-label"><span>NOMES QUE ATRAVESSARAM SÉCULOS</span></p>
              <h2>Pessoas, não apenas<br />personagens.</h2>
            </Reveal>
            <p>Governantes, estrategistas, guerreiras e rebeldes. Selecione um nome para conhecer sua história.</p>
          </div>
          <div className="figures-layout">
            <div className="figure-list" role="tablist" aria-label="Figuras históricas">
              {figures.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  role="tab"
                  aria-selected={activeFigure === item.id}
                  className={`figure-tab ${activeFigure === item.id ? "active" : ""}`}
                  onClick={() => setActiveFigure(item.id)}
                >
                  <span className="figure-jp">{item.jp}</span>
                  <span className="figure-info">
                    <b>{item.name}</b>
                    <small>{item.life}</small>
                  </span>
                </button>
              ))}
            </div>
            <article className="figure-detail" key={figure.id}>
              <div className="figure-portrait">
                <img src="/images/figures.jpg" alt="Interior tradicional japonês com suporte de espada e pergaminho" loading="lazy" />
                <span className="figure-kanji" aria-hidden="true">{figure.jp}</span>
              </div>
              <div className="figure-text">
                <span className="figure-era">{figure.era}</span>
                <h3>{figure.name}</h3>
                <p className="figure-role">{figure.role} · {figure.life}</p>
                <p className="figure-body">{figure.text}</p>
                <div className="figure-fact">
                  <b>POR QUE IMPORTA</b>
                  <p>{figure.fact}</p>
                </div>
                {figure.caution && (
                  <p className="figure-caution"><i />{figure.caution}</p>
                )}
              </div>
            </article>
          </div>
        </section>

        {/* ---------------- Lendas ---------------- */}
        <section className="legends-section" id="lendas">
          <div className="legends-bg" aria-hidden="true" />
          <div className="legends-inner">
            <div className="section-topline legends-topline"><span>05 / CONTADO E RECONTADO</span><span>伝説 · LENDAS</span></div>
            <div className="legends-heading">
              <Reveal>
                <p className="section-label"><span>ENTRE O REGISTRO E A NARRATIVA</span></p>
                <h2>Histórias que o Japão<br />conta há séculos.</h2>
              </Reveal>
              <p>Cada relato vem com uma nota sobre o que a documentação sustenta — e o que pertence à tradição.</p>
            </div>
            <div className="legend-list">
              {legends.map((legend, index) => {
                const open = openLegend === legend.id;
                return (
                  <Reveal key={legend.id} delay={(index % 3) * 60}>
                    <article className={`legend ${open ? "is-open" : ""}`}>
                      <button type="button" aria-expanded={open} onClick={() => setOpenLegend(open ? null : legend.id)}>
                        <span className="legend-jp">{legend.jp}</span>
                        <span className="legend-head">
                          <span className={`legend-kind kind-${legend.kind === "Lenda" ? "lenda" : legend.kind === "Fato histórico" ? "fato" : "misto"}`}>
                            {legend.kind}
                          </span>
                          <b>{legend.title}</b>
                          <small>{legend.lede}</small>
                        </span>
                        <i aria-hidden="true">{open ? "−" : "+"}</i>
                      </button>
                      {open && (
                        <div className="legend-body">
                          <p>{legend.text}</p>
                          <p className="legend-verdict"><b>O que se sabe:</b> {legend.verdict}</p>
                        </div>
                      )}
                    </article>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </section>

        {/* ---------------- Cerejeira ---------------- */}
        <section className="sakura-section" aria-label="Pausa visual com cerejeira em flor">
          <div className="sakura-image" aria-hidden="true" />
          <Petals className="sakura-petals" density={34} />
          <Reveal className="sakura-copy">
            <span className="sakura-jp" aria-hidden="true">桜</span>
            <p>A flor de cerejeira abre, cai e desaparece em poucos dias.</p>
            <small>MONO NO AWARE · A BELEZA DO QUE É PASSAGEIRO</small>
          </Reveal>
        </section>

        {/* ---------------- Mitos ---------------- */}
        <section className="myths-section" id="mitos">
          <div className="section-topline"><span>06 / HISTÓRIA CONTRA ESTEREÓTIPO</span><span>史実 · O QUE SABEMOS</span></div>
          <div className="myths-layout">
            <Reveal className="myths-intro">
              <p className="section-label"><span>FATO OU FICÇÃO?</span></p>
              <h2>O imaginário é recente.<br /><em>A história, mais complexa.</em></h2>
              <p>
                Filmes, romances e códigos de honra universais ajudaram a criar uma imagem poderosa do samurai.
                A documentação mostra nuances, mudanças e diferenças entre épocas.
              </p>
              <span className="myths-side-note">ABRA CADA IDEIA<br />PARA VER O CONTEXTO</span>
            </Reveal>
            <div className="myths-list">
              {myths.map((item, index) => (
                <div className={`myth ${openMyth === index ? "open" : ""}`} key={item.myth}>
                  <button type="button" aria-expanded={openMyth === index} onClick={() => setOpenMyth(openMyth === index ? null : index)}>
                    <span>0{index + 1}</span>
                    <b>{item.myth}</b>
                    <i aria-hidden="true">{openMyth === index ? "−" : "+"}</i>
                  </button>
                  {openMyth === index && (
                    <div className="myth-answer">
                      <p>{item.fact}</p>
                      <small>CONTEXTO · {item.source}</small>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ---------------- Curiosidades ---------------- */}
        <section className="curiosities-section" id="curiosidades">
          <div className="section-topline"><span>07 / DETALHES QUE FICAM</span><span>小話 · CURIOSIDADES</span></div>
          <div className="curiosity-heading">
            <Reveal>
              <p className="section-label"><span>PEQUENOS FRAGMENTOS</span></p>
              <h2>Olhe mais de perto.</h2>
            </Reveal>
            <p>Peças, costumes e fatos que ajudam a enxergar a vida para além do campo de batalha.</p>
          </div>
          <div className="curiosity-layout">
            <div className="curiosity-image">
              <img src="/images/samurai-armor.jpg" alt="Armadura samurai com placas laqueadas e elmo" loading="lazy" />
              <span>DETALHE · ARMADURA LAQUEADA</span>
            </div>
            <div className="curiosity-list">
              {curiosities.map((item, index) => (
                <article key={item.title} className={`curiosity ${openCuriosity === index ? "open" : ""}`}>
                  <button type="button" aria-expanded={openCuriosity === index} onClick={() => setOpenCuriosity(openCuriosity === index ? null : index)}>
                    <span className="curiosity-index">0{index + 1}</span>
                    <span className="curiosity-title">
                      <small>{item.tag}</small>
                      <b>{item.title}</b>
                    </span>
                    <i aria-hidden="true">{openCuriosity === index ? "−" : "+"}</i>
                  </button>
                  {openCuriosity === index && <p>{item.text}</p>}
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ---------------- Glossário ---------------- */}
        <section className="glossary-section" id="glossario">
          <div className="section-topline"><span>08 / PALAVRAS-CHAVE</span><span>語彙 · GLOSSÁRIO</span></div>
          <div className="glossary-head">
            <Reveal>
              <p className="section-label"><span>JAPONÊS · PORTUGUÊS</span></p>
              <h2>Um pequeno glossário.</h2>
            </Reveal>
            <label className="glossary-search">
              <span aria-hidden="true">⌕</span>
              <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar termo" aria-label="Buscar termo no glossário" />
            </label>
          </div>
          <div className="glossary-grid">
            {filteredGlossary.map((item, index) => (
              <Reveal key={item.term} delay={Math.min(index, 6) * 45}>
                <article className="glossary-entry">
                  <span className="glossary-kanji">{item.jp}</span>
                  <div>
                    <h3>{item.term}</h3>
                    <p>{item.meaning}</p>
                  </div>
                </article>
              </Reveal>
            ))}
          </div>
          {filteredGlossary.length === 0 && <p className="no-glossary">Nenhum termo encontrado para “{query}”.</p>}
        </section>

        {/* ---------------- Fontes ---------------- */}
        <section className="sources-section" id="fontes">
          <div className="sources-inner">
            <p className="section-label"><span>LEITURA E CRÉDITOS</span></p>
            <h2>História com fontes.<br /><em>Arte original.</em></h2>
            <p>
              Conteúdo histórico sintetizado a partir de materiais de museus e instituições de ensino.
              As imagens são ilustrações editoriais criadas para ambientar a leitura, não fotografias
              nem registros de peças históricas específicas.
            </p>
            <div className="sources-list">
              {sources.map((source, index) => (
                <a key={source.title} href={source.url} target="_blank" rel="noreferrer">
                  <span>0{index + 1}</span>
                  <div>
                    <b>{source.title}</b>
                    <small>{source.publisher}</small>
                  </div>
                  <Icon name="external" size={16} />
                </a>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <a className="footer-brand" href="#inicio"><span>侍</span><b>SAMURAI</b></a>
        <p>Uma introdução visual à história dos guerreiros do Japão.</p>
        <div>
          <span>日本の歴史 · HISTÓRIA JAPONESA</span>
          <a href="#inicio">VOLTAR AO INÍCIO <Icon name="up" size={14} /></a>
        </div>
      </footer>
    </div>
  );
}
