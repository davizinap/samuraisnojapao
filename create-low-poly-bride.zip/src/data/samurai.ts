/* ---------------------------------- Linha do tempo ---------------------------------- */

export type Period = {
  id: string;
  date: string;
  name: string;
  epithet: string;
  overview: string;
  details: { label: string; text: string }[];
  marker: string;
};

export const periods: Period[] = [
  {
    id: "heian",
    date: "794–1185",
    name: "Heian",
    epithet: "Servir antes de governar",
    overview:
      "Nas províncias, proprietários rurais recorriam a grupos armados para proteger terras e interesses. Dessas redes de serviço e parentesco emergiu a classe guerreira que séculos depois seria chamada de samurai.",
    details: [
      { label: "O poder", text: "A corte imperial permanecia em Quioto, enquanto autoridades locais e famílias guerreiras ampliavam sua influência nas províncias." },
      { label: "A prática", text: "Arco e cavalo eram centrais para os primeiros guerreiros. A imagem do espadachim solitário ainda não descreve esse mundo." },
      { label: "A palavra", text: "Samurai deriva de saburau: servir, atender. O termo nasce de uma relação de serviço, não apenas de combate." },
    ],
    marker: "弓 · ARCO",
  },
  {
    id: "kamakura",
    date: "c. 1185–1333",
    name: "Kamakura",
    epithet: "A ascensão do governo guerreiro",
    overview:
      "Depois das guerras entre os clãs Taira e Minamoto, Minamoto no Yoritomo estabeleceu em Kamakura um governo militar, o bakufu. A corte imperial continuou existindo, enquanto o xogum e seus vassalos consolidavam o poder político.",
    details: [
      { label: "O xogunato", text: "Um governo militar passou a administrar assuntos políticos ao lado das instituições imperiais." },
      { label: "O guerreiro", text: "Bushi, literalmente pessoa de guerra, é outro termo histórico para os membros dessa classe." },
      { label: "Os laços", text: "Lealdade, alianças, terras e obrigações entre senhor e vassalo formavam uma realidade política complexa." },
    ],
    marker: "鎌倉 · KAMAKURA",
  },
  {
    id: "sengoku",
    date: "1467–1600",
    name: "Sengoku",
    epithet: "O país em guerra",
    overview:
      "Conflitos entre senhores regionais marcaram o período. Exércitos cresceram, táticas mudaram e o repertório militar se ampliou: arqueiros, lanceiros, formações de infantaria e, a partir do século XVI, armas de fogo.",
    details: [
      { label: "Guerra em escala", text: "A batalha não era um duelo: tropas, terreno, logística, comando e alianças definiam campanhas inteiras." },
      { label: "Armas de fogo", text: "A chegada dos arcabuzes no século XVI influenciou a organização militar e o desenho das armaduras." },
      { label: "Identificação", text: "Elmos, estandartes e brasões ajudavam a reconhecer comandantes e unidades no campo de batalha." },
    ],
    marker: "戦国 · SENGOKU",
  },
  {
    id: "edo",
    date: "1603–1868",
    name: "Edo",
    epithet: "A espada na cidade",
    overview:
      "Com a longa paz do governo Tokugawa, muitos samurais passaram a ocupar cargos administrativos. A classe guerreira esteve ligada à educação, às artes, à burocracia e à vida das cidades-castelo.",
    details: [
      { label: "Outra função", text: "Em vez de combater, samurais atuavam na administração, na polícia, na justiça e até no combate a incêndios." },
      { label: "O daishō", text: "O par katana e wakizashi tornou-se um sinal visível de status samurai na sociedade de Edo." },
      { label: "Bushidō", text: "Ideais de conduta foram discutidos e sistematizados de formas diferentes. Não havia um manual único seguido por todos." },
    ],
    marker: "江戸 · EDO",
  },
  {
    id: "meiji",
    date: "1868–1877",
    name: "Meiji",
    epithet: "Uma classe em transformação",
    overview:
      "A restauração Meiji iniciou reformas que desmontaram a ordem feudal passo a passo. O serviço militar por conscrição, a reorganização dos domínios e as restrições ao porte de espadas mudaram o lugar social dos samurais.",
    details: [
      { label: "1873", text: "A conscrição criou um exército nacional, deixando de reservar a função militar a uma classe hereditária." },
      { label: "1876", text: "O Haitōrei restringiu o porte público de espadas, com exceções como militares e policiais." },
      { label: "1877", text: "A Rebelião de Satsuma foi a última grande revolta armada de antigos samurais contra o novo governo." },
    ],
    marker: "明治 · MEIJI",
  },
];

/* ---------------------------------- Armas ---------------------------------- */

export type Item = {
  id: string;
  name: string;
  jp: string;
  reading: string;
  era: string;
  kicker: string;
  text: string;
  note: string;
  specs: { label: string; value: string }[];
  image?: string;
  imageAlt?: string;
};

export const weapons: Item[] = [
  {
    id: "yumi",
    name: "Yumi",
    jp: "弓",
    reading: "arco longo japonês",
    era: "Séculos X–XVI",
    kicker: "A arma dos primeiros séculos",
    text: "Nos primeiros séculos da história samurai, a arquearia montada era a habilidade central. O yumi é um arco assimétrico: o punho fica abaixo do centro, o que facilita o uso a cavalo. Com o tempo, arcos de madeira laqueada deram lugar a laminados de madeira e bambu, mais potentes.",
    note: "Antes de ser o guerreiro da espada, o samurai era, antes de tudo, um arqueiro a cavalo.",
    specs: [
      { label: "Alcance", value: "Longa distância" },
      { label: "Material", value: "Bambu e madeira laqueada" },
      { label: "Uso", value: "A cavalo e a pé" },
    ],
    image: "/images/samurai-yumi.jpg",
    imageAlt: "Ilustração editorial de um arco japonês yumi com flechas",
  },
  {
    id: "katana",
    name: "Katana",
    jp: "刀",
    reading: "espada longa curva",
    era: "A partir do século XV",
    kicker: "Símbolo e ferramenta",
    text: "A katana tem lâmina curva de fio único, forjada em aço dobrado. Ganhou espaço quando os combates corpo a corpo se tornaram mais frequentes. Em Edo, também passou a comunicar posição social: o direito de portá-la era um marcador de status.",
    note: "Emblemática, mas não foi a arma principal dos primeiros samurais.",
    specs: [
      { label: "Lâmina", value: "Cerca de 60–80 cm" },
      { label: "Forja", value: "Aço dobrado e temperado" },
      { label: "Porte", value: "Fio voltado para cima" },
    ],
    image: "/images/samurai-daisho.jpg",
    imageAlt: "Ilustração editorial de um par daishō: katana e wakizashi",
  },
  {
    id: "wakizashi",
    name: "Wakizashi",
    jp: "脇差",
    reading: "espada curta",
    era: "Período Edo",
    kicker: "A outra metade do par",
    text: "Mais curta que a katana, a wakizashi acompanhava o guerreiro em ambientes fechados, onde a lâmina longa era pouco prática. Juntas, as duas formam o daishō — literalmente “grande e pequena”.",
    note: "O par daishō tornou-se um sinal visível de pertencimento à classe samurai.",
    specs: [
      { label: "Lâmina", value: "Cerca de 30–60 cm" },
      { label: "Conjunto", value: "Katana + wakizashi = daishō" },
      { label: "Uso", value: "Espaços internos e reserva" },
    ],
  },
  {
    id: "naginata",
    name: "Naginata",
    jp: "薙刀",
    reading: "arma de haste com lâmina curva",
    era: "Séculos XII–XIX",
    kicker: "Alcance e formação",
    text: "A naginata combina uma lâmina curva e uma haste comprida. Era eficaz contra cavalaria e em formações de infantaria. No período Edo, tornou-se também arma associada ao treinamento de mulheres de famílias samurai.",
    note: "Armas de haste dominavam o campo de batalha muito mais do que o imaginário popular sugere.",
    specs: [
      { label: "Comprimento", value: "Haste longa, até ~2 m" },
      { label: "Vantagem", value: "Manter distância" },
      { label: "Edo", value: "Escolas de naginatajutsu" },
    ],
  },
  {
    id: "yari",
    name: "Yari",
    jp: "槍",
    reading: "lança reta",
    era: "Período Sengoku",
    kicker: "A arma dos exércitos",
    text: "A lança reta foi a arma mais comum dos grandes exércitos do período Sengoku. Formações de lanceiros (ashigaru) sustentavam linhas inteiras de batalha, com alcance e custo muito menores que os de uma espada forjada.",
    note: "A maior parte das vítimas em batalha não caía por espadas, e sim por projéteis e armas de haste.",
    specs: [
      { label: "Formato", value: "Lâmina reta na ponta" },
      { label: "Tropa", value: "Usada em massa por ashigaru" },
      { label: "Função", value: "Linhas e cargas" },
    ],
  },
  {
    id: "tanegashima",
    name: "Tanegashima",
    jp: "種子島",
    reading: "arcabuz de mecha",
    era: "A partir de 1543",
    kicker: "A pólvora chega ao Japão",
    text: "Armas de fogo de mecha entraram no Japão pelo contato com comerciantes portugueses em meados do século XVI. Produzidas localmente em pouco tempo, mudaram táticas, treinamento de tropas e o próprio desenho das armaduras.",
    note: "A tecnologia europeia foi adotada, copiada e adaptada com rapidez notável.",
    specs: [
      { label: "Origem", value: "Contato com portugueses" },
      { label: "Mecanismo", value: "Disparo por mecha" },
      { label: "Efeito", value: "Armaduras à prova de bala" },
    ],
  },
  {
    id: "tanto",
    name: "Tantō",
    jp: "短刀",
    reading: "adaga",
    era: "Séculos X–XIX",
    kicker: "A lâmina curta",
    text: "Adaga de lâmina curta, usada tanto como arma auxiliar quanto como objeto do cotidiano. Mulheres de famílias samurai também portavam uma versão pequena, o kaiken, guardada nas vestes.",
    note: "Pequeno, discreto e presente em contextos muito diferentes entre si.",
    specs: [
      { label: "Lâmina", value: "Menos de 30 cm" },
      { label: "Variação", value: "Kaiken, usado por mulheres" },
      { label: "Uso", value: "Arma auxiliar e utilitária" },
    ],
  },
  {
    id: "tessen",
    name: "Tessen",
    jp: "鉄扇",
    reading: "leque de ferro",
    era: "Período Edo",
    kicker: "A arma que não parecia arma",
    text: "Leque com varetas de ferro. Comandantes usavam versões robustas para sinalizar ordens no campo de batalha; outras serviam como defesa discreta em locais onde portar espada não era permitido.",
    note: "Também havia o gunbai, leque sólido usado por comandantes para dar ordens.",
    specs: [
      { label: "Material", value: "Ferro e madeira" },
      { label: "Função", value: "Sinalização e defesa" },
      { label: "Discrição", value: "Permitido onde espadas não eram" },
    ],
  },
];

/* ---------------------------------- Armaduras ---------------------------------- */

export const armorParts: Item[] = [
  {
    id: "oyoroi",
    name: "Ō-yoroi",
    jp: "大鎧",
    reading: "a grande armadura",
    era: "Séculos X–XIV",
    kicker: "Feita para o arqueiro a cavalo",
    text: "Armadura antiga, de forma larga e quadrada, pensada para quem atirava com arco montado. Podia reunir cerca de 2.000 pequenas escamas de ferro ou couro laqueado, amarradas com cordões de seda: resistente, mas flexível.",
    note: "As grandes ombreiras (sode) funcionavam quase como escudos móveis contra flechas.",
    specs: [
      { label: "Escamas", value: "~2.000 placas laqueadas" },
      { label: "Peso", value: "Aproximadamente 25–30 kg" },
      { label: "Feita para", value: "Arquearia a cavalo" },
    ],
    image: "/images/samurai-armor.jpg",
    imageAlt: "Ilustração editorial de uma armadura lamelar japonesa com elmo kabuto",
  },
  {
    id: "domaru",
    name: "Dōmaru",
    jp: "胴丸",
    reading: "que envolve o torso",
    era: "Séculos XIV–XVI",
    kicker: "Leveza para lutar a pé",
    text: "Quando as táticas mudaram de duelos montados para formações de infantaria, a armadura acompanhou. O dōmaru é mais justo ao corpo e mais leve, permitindo maior mobilidade em combate a pé.",
    note: "A forma da armadura conta como se lutava em cada época.",
    specs: [
      { label: "Formato", value: "Envolve o torso, peça única" },
      { label: "Vantagem", value: "Leveza e mobilidade" },
      { label: "Contexto", value: "Infantaria em formação" },
    ],
  },
  {
    id: "tosei",
    name: "Tōsei-gusoku",
    jp: "当世具足",
    reading: "armadura moderna",
    era: "Século XVI em diante",
    kicker: "Resposta às armas de fogo",
    text: "Com a difusão dos arcabuzes, surgiram peitorais de placas maiores e mais sólidas, algumas testadas contra tiros. O nome significa, literalmente, “armadura dos tempos atuais”.",
    note: "Algumas peças traziam a marca do projétil usado no teste, como prova de resistência.",
    specs: [
      { label: "Peitoral", value: "Placas sólidas de ferro" },
      { label: "Motivo", value: "Proteção contra projéteis" },
      { label: "Estilo", value: "Formas muito variadas" },
    ],
  },
  {
    id: "kabuto",
    name: "Kabuto",
    jp: "兜",
    reading: "elmo",
    era: "Todos os períodos",
    kicker: "Identidade no campo de batalha",
    text: "Mais do que proteção, o elmo era identificação. No período Sengoku, cristas (maedate) e formatos extravagantes — chifres, luas crescentes, símbolos budistas — tornavam comandantes reconhecíveis em meio ao caos.",
    note: "Reconhecer o comandante inspirava as tropas e garantia crédito por atos de bravura.",
    specs: [
      { label: "Estrutura", value: "Placas de ferro rebitadas" },
      { label: "Crista", value: "Maedate, frontal e distintiva" },
      { label: "Proteção", value: "Shikoro protegia a nuca" },
    ],
  },
  {
    id: "menpo",
    name: "Menpō",
    jp: "面頬",
    reading: "máscara facial",
    era: "Séculos XV–XIX",
    kicker: "O rosto da guerra",
    text: "Máscaras de ferro ou couro laqueado protegiam o rosto e ajudavam a prender o elmo com firmeza. Muitas traziam expressões ferozes, bigodes de pelo real e dentes pintados — intimidar fazia parte da função.",
    note: "A expressão da máscara era uma escolha estética e psicológica, não apenas defensiva.",
    specs: [
      { label: "Cobertura", value: "Rosto total ou parcial" },
      { label: "Detalhe", value: "Bigodes e dentes pintados" },
      { label: "Função extra", value: "Fixar o elmo no lugar" },
    ],
  },
  {
    id: "sashimono",
    name: "Sashimono",
    jp: "指物",
    reading: "estandarte de costas",
    era: "Período Sengoku",
    kicker: "Quem é quem na batalha",
    text: "Pequenas bandeiras presas às costas da armadura identificavam a unidade e o senhor a que o guerreiro servia. Em exércitos de milhares de pessoas, essa sinalização visual era essencial para o comando.",
    note: "Cores e brasões (mon) funcionavam como um sistema de reconhecimento em campo.",
    specs: [
      { label: "Posição", value: "Preso às costas" },
      { label: "Conteúdo", value: "Brasão do clã (mon)" },
      { label: "Função", value: "Identificar unidades" },
    ],
  },
];

/* ---------------------------------- Figuras ---------------------------------- */

export type Figure = {
  id: string;
  name: string;
  jp: string;
  life: string;
  role: string;
  era: string;
  text: string;
  fact: string;
  caution?: string;
};

export const figures: Figure[] = [
  {
    id: "yoritomo",
    name: "Minamoto no Yoritomo",
    jp: "源頼朝",
    life: "1147–1199",
    role: "Primeiro xogum de Kamakura",
    era: "Kamakura",
    text: "Venceu o clã Taira nas guerras Genpei e estabeleceu em Kamakura o primeiro governo militar duradouro do Japão. A corte imperial continuou existindo, mas o poder efetivo passou a ser disputado a partir de outro centro.",
    fact: "Seu governo criou a estrutura que colocaria a classe guerreira no comando político por quase sete séculos.",
  },
  {
    id: "tomoe",
    name: "Tomoe Gozen",
    jp: "巴御前",
    life: "século XII",
    role: "Guerreira das guerras Genpei",
    era: "Heian / Kamakura",
    text: "Descrita no Heike Monogatari como arqueira e amazona excepcional, que combateu ao lado de Minamoto no Yoshinaka. Tornou-se a figura mais conhecida entre as onna-musha, as mulheres guerreiras.",
    fact: "Escavações em campos de batalha do período Sengoku encontraram restos femininos entre os mortos, indicando participação real de mulheres em combate.",
    caution: "É conhecida sobretudo por relatos literários; os detalhes de sua vida são difíceis de confirmar.",
  },
  {
    id: "masako",
    name: "Hōjō Masako",
    jp: "北条政子",
    life: "1156–1225",
    role: "Religiosa e líder política",
    era: "Kamakura",
    text: "Esposa de Yoritomo, exerceu enorme influência política após a morte do marido. Ficou conhecida como “a monja xogum” por conduzir decisões de Estado em um momento crítico do xogunato.",
    fact: "Mostra que o poder dentro da classe samurai não se resumia ao campo de batalha nem a figuras masculinas.",
  },
  {
    id: "nobunaga",
    name: "Oda Nobunaga",
    jp: "織田信長",
    life: "1534–1582",
    role: "Senhor da guerra unificador",
    era: "Sengoku",
    text: "Primeiro dos três grandes unificadores. Reorganizou exércitos, adotou armas de fogo em larga escala e rompeu com estruturas tradicionais de poder. Morreu em Honnō-ji, traído por um de seus generais.",
    fact: "Sua disposição para incorporar tecnologia e tática estrangeira mudou o modo de fazer guerra no Japão.",
  },
  {
    id: "hideyoshi",
    name: "Toyotomi Hideyoshi",
    jp: "豊臣秀吉",
    life: "1537–1598",
    role: "Unificador e administrador",
    era: "Sengoku / Momoyama",
    text: "De origem humilde, ascendeu servindo Nobunaga até se tornar a figura mais poderosa do Japão. Completou a unificação e reorganizou a sociedade em categorias rígidas.",
    fact: "Em 1588 ordenou a “caça às espadas”, retirando armas de camponeses e endurecendo a separação entre as classes.",
  },
  {
    id: "ieyasu",
    name: "Tokugawa Ieyasu",
    jp: "徳川家康",
    life: "1543–1616",
    role: "Fundador do xogunato Tokugawa",
    era: "Sengoku / Edo",
    text: "Venceu em Sekigahara (1600) e tornou-se xogum em 1603, inaugurando mais de dois séculos e meio de governo Tokugawa e de paz interna relativa.",
    fact: "A paz que seu regime estabeleceu transformou guerreiros em administradores, mudando o significado de ser samurai.",
  },
  {
    id: "masamune",
    name: "Date Masamune",
    jp: "伊達政宗",
    life: "1567–1636",
    role: "Daimyō do norte",
    era: "Sengoku / Edo",
    text: "Senhor do domínio de Sendai, reconhecido pelo elmo com crista em lua crescente e por ter perdido a visão de um olho ainda jovem. Patrocinou uma embaixada que atravessou o Pacífico rumo ao México, à Espanha e a Roma.",
    fact: "A missão Keichō, que ele enviou em 1613, é um dos primeiros contatos diplomáticos diretos entre o Japão e a Europa.",
  },
  {
    id: "musashi",
    name: "Miyamoto Musashi",
    jp: "宮本武蔵",
    life: "c. 1584–1645",
    role: "Espadachim, escritor e pintor",
    era: "Edo",
    text: "Célebre pela técnica de duas espadas e por uma série de duelos. No fim da vida escreveu o Go Rin no Sho, o Livro dos Cinco Anéis, sobre estratégia. Também deixou pinturas e caligrafias respeitadas.",
    fact: "É exemplo do ideal bun-bu: o cultivo conjunto das artes marciais e das artes da cultura.",
    caution: "Boa parte de sua biografia vem de relatos posteriores, com elementos lendários acrescentados.",
  },
  {
    id: "saigo",
    name: "Saigō Takamori",
    jp: "西郷隆盛",
    life: "1828–1877",
    role: "Líder da Rebelião de Satsuma",
    era: "Meiji",
    text: "Ajudou a construir o governo Meiji e depois liderou a última grande revolta armada de antigos samurais contra as reformas que desmontaram sua classe. Morreu em Shiroyama, em 1877.",
    fact: "Ficou conhecido como “o último samurai”, embora o próprio processo histórico tenha sido muito mais gradual.",
  },
];

/* ---------------------------------- Lendas ---------------------------------- */

export type Legend = {
  id: string;
  title: string;
  jp: string;
  kind: "Fato histórico" | "História e lenda" | "Lenda";
  lede: string;
  text: string;
  verdict: string;
};

export const legends: Legend[] = [
  {
    id: "ako",
    title: "Os 47 rōnin",
    jp: "忠臣蔵",
    kind: "História e lenda",
    lede: "Uma vingança real que virou o maior clássico do teatro japonês.",
    text: "Em 1701, o senhor Asano foi condenado à morte após ferir um alto funcionário no castelo de Edo. Seus retentores, agora rōnin, planejaram em silêncio por quase dois anos e, em 1703, invadiram a residência do inimigo. Depois, entregaram-se às autoridades e foram condenados a tirar a própria vida.",
    verdict: "O incidente de Akō aconteceu de fato. As versões do teatro kabuki e da literatura acrescentaram diálogos, personagens e motivações.",
  },
  {
    id: "ganryujima",
    title: "O duelo em Ganryūjima",
    jp: "巌流島",
    kind: "História e lenda",
    lede: "Musashi contra Sasaki Kojirō, numa ilha ao amanhecer.",
    text: "Conta-se que Miyamoto Musashi chegou atrasado ao duelo, remando até a ilha, e enfrentou Sasaki Kojirō empunhando um bastão de madeira talhado de um remo — mais longo que a célebre lâmina do adversário.",
    verdict: "Um duelo em 1612 é aceito como provável, mas os detalhes mais famosos vêm de narrativas escritas muito depois.",
  },
  {
    id: "benkei",
    title: "Benkei na ponte Gojō",
    jp: "弁慶",
    kind: "Lenda",
    lede: "O monge guerreiro que juntou 999 espadas.",
    text: "Segundo a tradição, o enorme monge Benkei desafiava guerreiros na ponte Gojō, em Quioto, tomando suas espadas. Na milésima tentativa, foi vencido pelo jovem e ágil Minamoto no Yoshitsune, de quem se tornou vassalo fiel até a morte.",
    verdict: "Benkei pode ter existido, mas o episódio da ponte pertence ao campo da lenda e da literatura épica.",
  },
  {
    id: "masakado",
    title: "O espírito de Taira no Masakado",
    jp: "平将門",
    kind: "História e lenda",
    lede: "O rebelde do século X que virou divindade protetora de Tóquio.",
    text: "Masakado liderou uma revolta contra a corte e foi morto em 940. Conta-se que sua cabeça teria voado de volta ao leste. O túmulo atribuído a ele permanece até hoje no bairro financeiro de Ōtemachi, em Tóquio, cercado de histórias sobre azares que teriam atingido quem tentou removê-lo.",
    verdict: "A revolta e a execução são históricas. O restante pertence ao folclore urbano, que segue vivo.",
  },
  {
    id: "hachiman",
    title: "Hachiman, o kami dos guerreiros",
    jp: "八幡",
    kind: "Lenda",
    lede: "A divindade adotada como protetora dos Minamoto.",
    text: "Hachiman tornou-se a divindade protetora dos guerreiros, especialmente do clã Minamoto. Yoritomo fez do santuário Tsurugaoka Hachiman-gū um centro simbólico de Kamakura, ligando poder militar e legitimidade religiosa.",
    verdict: "A devoção é um fato histórico documentado; as narrativas sobre a divindade pertencem à tradição religiosa.",
  },
  {
    id: "seppuku",
    title: "O ritual do seppuku",
    jp: "切腹",
    kind: "Fato histórico",
    lede: "Uma prática real, com regras — e muito menos comum do que o cinema sugere.",
    text: "O suicídio ritual existia como forma de evitar a captura, cumprir sentença ou protestar. Era cercado de protocolo, incluindo a figura do kaishakunin, responsável por abreviar o sofrimento. No período Edo, tornou-se também uma pena judicial formal aplicada à classe samurai.",
    verdict: "Documentado, mas raro no cotidiano. A ficção ampliou enormemente sua frequência e seu romantismo.",
  },
];

/* ---------------------------------- Mitos ---------------------------------- */

export const myths = [
  {
    myth: "Todo samurai lutava o tempo inteiro.",
    fact: "Não. Durante a paz de Edo, muitos exerceram funções de governo, administração, polícia, justiça, educação e vida urbana. Havia samurais que nunca participaram de uma batalha.",
    source: "British Museum · Who were the samurai?",
  },
  {
    myth: "A katana sempre foi a principal arma samurai.",
    fact: "Nos primeiros séculos, a arquearia montada era central, e lanças dominavam os grandes exércitos. A espada ganhou espaço no combate corpo a corpo e como símbolo de status.",
    source: "British Museum · Who were the samurai?",
  },
  {
    myth: "Todos seguiam o mesmo código Bushidō, com sete virtudes fixas.",
    fact: "Códigos e ideais guerreiros variaram entre clãs, pessoas e séculos. A imagem de um código único e uniforme foi consolidada muito mais tarde, sobretudo a partir do fim do século XIX.",
    source: "British Museum · Met Museum",
  },
  {
    myth: "Samurai era sinônimo de homem.",
    fact: "Samurai era uma classe social que incluía famílias inteiras. Mulheres recebiam treinamento com armas, administravam propriedades e, em alguns casos documentados, participaram de combates.",
    source: "British Museum · Samurai (exposição)",
  },
  {
    myth: "A era samurai terminou num único dia.",
    fact: "Não houve virada isolada: as reformas Meiji alteraram domínios, rendas, serviço militar e privilégios em etapas, ao longo dos anos 1870.",
    source: "Asia for Educators · Columbia University",
  },
  {
    myth: "Ninjas e samurais eram inimigos naturais.",
    fact: "A imagem do confronto entre os dois grupos vem em grande parte da ficção moderna. Atividades de espionagem e infiltração eram contratadas e usadas por senhores de guerra como parte da estratégia.",
    source: "Síntese de literatura histórica",
  },
];

/* ---------------------------------- Curiosidades ---------------------------------- */

export const curiosities = [
  {
    title: "A armadura podia ter milhares de peças minúsculas.",
    text: "O ō-yoroi reunia cerca de 2.000 escamas de ferro ou couro laqueado, amarradas com cordões de seda coloridos. O resultado precisava ser resistente sem travar os movimentos do arqueiro.",
    tag: "ARMADURA",
  },
  {
    title: "Elmos funcionavam como identificação visual.",
    text: "No período Sengoku, cristas e formatos extravagantes ajudavam a reconhecer comandantes no tumulto da batalha, inspirando as tropas e garantindo crédito por atos de bravura.",
    tag: "KABUTO",
  },
  {
    title: "A pólvora mudou o desenho das proteções.",
    text: "Com a chegada dos arcabuzes no século XVI, armaduras passaram a incorporar placas maiores e mais sólidas. Algumas peças ostentavam a marca do tiro de teste como garantia de qualidade.",
    tag: "TECNOLOGIA",
  },
  {
    title: "Combater incêndios era trabalho de samurai.",
    text: "Nas cidades densas e construídas em madeira do período Tokugawa, o fogo era uma ameaça constante. Alguns samurais eram designados exatamente para esse serviço urbano.",
    tag: "VIDA EM EDO",
  },
  {
    title: "A palavra samurai aponta para serviço.",
    text: "O termo deriva do verbo saburau, associado a servir ou atender. O vínculo com um senhor e uma casa era parte central da identidade, muito antes do imaginário do guerreiro solitário.",
    tag: "ETIMOLOGIA",
  },
  {
    title: "Arquearia também era passatempo doméstico.",
    text: "Registros do período Edo descrevem a arquearia de interior como lazer de homens, mulheres e crianças de famílias samurai, com arcos pequenos e alvos suspensos.",
    tag: "COTIDIANO",
  },
  {
    title: "Escrever e pintar faziam parte do ofício.",
    text: "O ideal bun-bu ryōdō unia “as artes da escrita e as artes da guerra”. Esperava-se que o guerreiro fosse também letrado: poesia, caligrafia e cerimônia do chá integravam sua formação.",
    tag: "CULTURA",
  },
  {
    title: "Nem todo samurai tinha dinheiro.",
    text: "Pagos em arroz e com rendas fixas, muitos samurais de baixa patente enfrentaram dificuldades financeiras ao longo do período Edo, enquanto comerciantes — formalmente abaixo deles — enriqueciam.",
    tag: "ECONOMIA",
  },
];

/* ---------------------------------- Glossário ---------------------------------- */

export const glossary = [
  { jp: "侍", term: "Samurai", meaning: "Guerreiro-retentor; o termo vem de “servir”." },
  { jp: "武士", term: "Bushi", meaning: "Pessoa da classe guerreira; termo histórico mais amplo." },
  { jp: "将軍", term: "Shōgun", meaning: "Líder militar que chefiava o governo, o bakufu." },
  { jp: "大名", term: "Daimyō", meaning: "Senhor regional que governava um domínio." },
  { jp: "浪人", term: "Rōnin", meaning: "Samurai sem senhor ou sem vínculo de serviço ativo." },
  { jp: "武士道", term: "Bushidō", meaning: "“Caminho do guerreiro”; ideia que mudou muito conforme a época." },
  { jp: "足軽", term: "Ashigaru", meaning: "Soldado de infantaria, base dos grandes exércitos." },
  { jp: "幕府", term: "Bakufu", meaning: "O governo militar liderado pelo xogum." },
  { jp: "女武者", term: "Onna-musha", meaning: "Mulher da classe guerreira treinada em combate." },
  { jp: "家紋", term: "Kamon", meaning: "Brasão de família, usado em roupas, bandeiras e armaduras." },
  { jp: "切腹", term: "Seppuku", meaning: "Suicídio ritual, cercado de protocolo rigoroso." },
  { jp: "刀狩", term: "Katanagari", meaning: "A “caça às espadas” de 1588, que desarmou camponeses." },
];

/* ---------------------------------- Fontes ---------------------------------- */

export const sources = [
  {
    title: "Who were the samurai?",
    publisher: "The British Museum · 2025",
    url: "https://www.britishmuseum.org/blog/who-were-samurai",
  },
  {
    title: "Samurai — Large print guide",
    publisher: "The British Museum · 2026",
    url: "https://www.britishmuseum.org/exhibitions/samurai/samurai-large-print-guide",
  },
  {
    title: "Samurai — Heilbrunn Timeline of Art History",
    publisher: "The Metropolitan Museum of Art",
    url: "https://www.metmuseum.org/essays/samurai",
  },
  {
    title: "Art of the Samurai: Japanese Arms and Armor, 1156–1868",
    publisher: "The Metropolitan Museum of Art",
    url: "https://www.metmuseum.org/exhibitions/listings/2009/art-of-the-samurai",
  },
  {
    title: "The Meiji Restoration and Modernization",
    publisher: "Columbia University · Asia for Educators",
    url: "https://afe.easia.columbia.edu/special/japan_1750_meiji.htm",
  },
  {
    title: "The History of Samurai — Background Notes for Teachers",
    publisher: "The Japan Society (Reino Unido)",
    url: "https://www.japansociety.org.uk/resource?resource=119",
  },
];
