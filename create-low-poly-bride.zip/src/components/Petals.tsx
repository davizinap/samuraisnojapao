import { useEffect, useRef } from "react";

type Petal = {
  x: number;
  y: number;
  size: number;
  speed: number;
  drift: number;
  phase: number;
  spin: number;
  angle: number;
  flip: number;
  tone: number;
};

/**
 * Pétalas de cerejeira caindo, desenhadas em canvas.
 * Pausa quando sai da tela e respeita a preferência por menos movimento.
 */
export default function Petals({ density = 26, className = "" }: { density?: number; className?: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let width = 0;
    let height = 0;
    let petals: Petal[] = [];
    let raf = 0;
    let visible = true;
    let last = 0;

    const tones = [
      [249, 214, 222],
      [244, 198, 210],
      [252, 230, 234],
      [236, 182, 196],
    ];

    const make = (initial: boolean): Petal => ({
      x: Math.random() * width,
      y: initial ? Math.random() * height : -20 - Math.random() * 80,
      size: 6 + Math.random() * 8,
      speed: 14 + Math.random() * 26,
      drift: 10 + Math.random() * 26,
      phase: Math.random() * Math.PI * 2,
      spin: (Math.random() - 0.5) * 1.4,
      angle: Math.random() * Math.PI * 2,
      flip: 0.45 + Math.random() * 0.55,
      tone: Math.floor(Math.random() * tones.length),
    });

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(density, Math.max(10, (width * height) / 26000)));
      petals = Array.from({ length: count }, () => make(true));
    };

    const drawPetal = (p: Petal) => {
      const [r, g, b] = tones[p.tone];
      const squash = Math.abs(Math.cos(p.phase * 0.9)) * p.flip + 0.35;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.angle);
      ctx.scale(1, squash);
      ctx.beginPath();
      // formato de pétala: base estreita, topo arredondado com leve chanfro
      ctx.moveTo(0, p.size * 0.5);
      ctx.bezierCurveTo(-p.size * 0.62, p.size * 0.1, -p.size * 0.5, -p.size * 0.52, 0, -p.size * 0.58);
      ctx.bezierCurveTo(p.size * 0.5, -p.size * 0.52, p.size * 0.62, p.size * 0.1, 0, p.size * 0.5);
      ctx.closePath();
      ctx.fillStyle = `rgba(${r}, ${g}, ${b}, 0.9)`;
      ctx.fill();
      ctx.restore();
    };

    const frame = (time: number) => {
      raf = requestAnimationFrame(frame);
      if (!visible) {
        last = time;
        return;
      }
      const dt = Math.min(0.05, (time - last) / 1000 || 0);
      last = time;

      ctx.clearRect(0, 0, width, height);
      for (const p of petals) {
        p.y += p.speed * dt;
        p.phase += dt * 1.6;
        p.x += Math.sin(p.phase) * p.drift * dt;
        p.angle += p.spin * dt;
        if (p.y - p.size > height) Object.assign(p, make(false));
        if (p.x < -40) p.x = width + 30;
        if (p.x > width + 40) p.x = -30;
        drawPetal(p);
      }
    };

    resize();

    if (reduced) {
      // sem animação: desenha um quadro estático discreto
      ctx.clearRect(0, 0, width, height);
      petals.forEach(drawPetal);
      return;
    }

    const io = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
    });
    io.observe(canvas);

    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    raf = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(raf);
      io.disconnect();
      ro.disconnect();
    };
  }, [density]);

  return <canvas ref={ref} className={`petals ${className}`} aria-hidden="true" />;
}
